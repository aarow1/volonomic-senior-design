% Add student code to path
addpath(genpath('student_code'))
% Add path to framework
addpath(genpath('framework'))
%
% Now you can start your quadrotor like this:
%
% Create quad object to start quadrotor control
% quad = QuadrotorROS('crazym04');
%
% Then take off:
%
% quad.takeoff
%


