function [ x ] = ssd(v1, v2)
x = sumsqr(v1 - v2);
end

