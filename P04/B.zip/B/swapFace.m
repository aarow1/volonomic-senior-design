function [ output_args ] = swapFace( idxList )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here


end

